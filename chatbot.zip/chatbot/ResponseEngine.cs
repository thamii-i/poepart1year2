﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace chatbot
{
    public class ResponseEngine
    {
        private List<string> ignore = new List<string>();
        private List<string> answers = new List<string>();
        private List<string> phishingTips = new List<string>();

        public string UserName { get; set; } = "User";
        public string FavoriteTopic { get; set; } = null;
        public string CurrentTopic { get; set; } = null;

        private List<string> followUpKeywords = new List<string> { "give me another tip", "explain more", "tell me more" };

        public ResponseEngine()
        {
            // Retained from original code
            ignore.Add("please");
            ignore.Add("can");
            ignore.Add("you");
            ignore.Add("tell");
            ignore.Add("me");
            ignore.Add("about");

            answers.Add("password");
            answers.Add("phishing");
            answers.Add("purpose");
            answers.Add("how are you");
            answers.Add("scam");
            answers.Add("privacy");

            phishingTips.Add("Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organisations.");
            phishingTips.Add("Always check the sender's email address closely. Slight misspellings are a major red flag!");
            phishingTips.Add("Never click on suspicious links or download attachments from unexpected emails.");
        }

        private string DetectSentiment(string input)
        {
            if (input.Contains("worried") || input.Contains("scared") || input.Contains("afraid"))
                return "worried";
            if (input.Contains("frustrated") || input.Contains("angry") || input.Contains("annoyed"))
                return "frustrated";
            return "neutral";
        }

        public string GetResponse(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return "System: Input text field cannot be empty.";

            string cleanInput = input.ToLower().Trim();

            if (cleanInput == "exit" || cleanInput == "quit")
                return "EXIT_SIGNAL";

            var words = cleanInput.Split(' ').Where(w => !ignore.Contains(w)).ToList();
            string filteredInput = string.Join(" ", words);

            string sentiment = DetectSentiment(cleanInput);
            string sentimentPrefix = "";
            if (sentiment == "worried")
                sentimentPrefix = "It's completely understandable to feel anxious about security threats. ";
            else if (sentiment == "frustrated")
                sentimentPrefix = "I understand security adjustments can be annoying, but they keep your data safe! ";

            // Memory assignments
            if (cleanInput.Contains("my name is "))
            {
                int index = cleanInput.IndexOf("my name is ") + 11;
                UserName = input.Substring(index).Trim();
                return $"Chatbot: Great to meet you, {UserName}! How can I assist you with your security questions today?";
            }
            if (cleanInput.Contains("i'm interested in ") || cleanInput.Contains("i am interested in "))
            {
                string marker = cleanInput.Contains("i'm interested in ") ? "i'm interested in " : "i am interested in ";
                int index = cleanInput.IndexOf(marker) + marker.Length;
                FavoriteTopic = input.Substring(index).Trim().Replace(".", "");
                return $"Chatbot: I've noted down your interest area: {FavoriteTopic}.";
            }

            // Flow loops
            if (followUpKeywords.Any(fk => cleanInput.Contains(fk)))
            {
                if (CurrentTopic == "phishing")
                {
                    Random rand = new Random();
                    return $"Chatbot: Another phishing pointer: {phishingTips[rand.Next(phishingTips.Count)]}";
                }
                if (!string.IsNullOrEmpty(CurrentTopic))
                {
                    return $"Chatbot: Expanding on '{CurrentTopic}': Always remember to verify source links independently.";
                }
                return "Chatbot: I am ready to elaborate! Let me know if you want to expand on passwords, scams, or privacy controls.";
            }

            // Topic extraction execution
            if (answers.Any(a => filteredInput.Contains(a) || cleanInput.Contains(a)))
            {
                if (cleanInput.Contains("how are you"))
                    return "Chatbot: Systems are secure and operational.";

                if (cleanInput.Contains("purpose"))
                    return "Chatbot: My purpose is to help you stay safe online by teaching you about cybersecurity.";

                if (cleanInput.Contains("password"))
                {
                    CurrentTopic = "password";
                    return $"Chatbot: {sentimentPrefix}Use a strong unique password with varied symbols and never repeat passphrases.";
                }

                if (cleanInput.Contains("phishing") || cleanInput.Contains("tip"))
                {
                    CurrentTopic = "phishing";
                    Random rand = new Random();
                    return $"Chatbot: {sentimentPrefix}{phishingTips[rand.Next(phishingTips.Count)]}";
                }

                if (cleanInput.Contains("scam"))
                {
                    CurrentTopic = "scam";
                    return $"Chatbot: {sentimentPrefix}Always double check unexpected requests before dealing with transactions.";
                }

                if (cleanInput.Contains("privacy"))
                {
                    CurrentTopic = "privacy";
                    return $"Chatbot: Lock down profile security data parameters and activate Multi-Factor Verification checks.";
                }
            }

            return "Chatbot: Content match not detected. Try checking for 'passwords', 'scams', 'privacy' or get a 'phishing tip'.";
        }
    }
}