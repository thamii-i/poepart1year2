﻿using System.Media;
using System.Security.Claims;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace chatbot
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ResponseEngine botBrain;

        MediaPlayer player = new MediaPlayer();

        public MainWindow()
        {
            InitializeComponent();
            botBrain = new ResponseEngine();
            player.Open(new Uri("greet_voice.wav", UriKind.Relative));
            player.Play();

           
            AppendMessageLog("Chatbot: Hello! I am SecureBot. What is your name? (Or type 'my name is [name]')", Brushes.DarkGray);
            UserInputTextBox.Focus();
        }

        private void AppendMessageLog(string message, Brush colorStyle)
        {
            Paragraph newParagraph = new Paragraph(new Run(message));
            newParagraph.Foreground = colorStyle;
            newParagraph.Margin = new Thickness(0, 2, 0, 2);
            ChatLogDisplay.Document.Blocks.Add(newParagraph);
            ChatLogDisplay.ScrollToEnd();
        }

        private void ProcessMessageCycle()
        {
            string textPayload = UserInputTextBox.Text.Trim();
            if (string.IsNullOrEmpty(textPayload)) return;

            AppendMessageLog($"[{botBrain.UserName}]: {textPayload}", Brushes.DeepSkyBlue);
            UserInputTextBox.Clear();

            string outcomeResponse = botBrain.GetResponse(textPayload);

            if (outcomeResponse == "EXIT_SIGNAL")
            {
                ExecuteSafeShutdownSequence();
            }
            else
            {
                AppendMessageLog(outcomeResponse, Brushes.LightGreen);
            }
        }

        private void ExecuteSafeShutdownSequence()
        {
            AppendMessageLog($"{Environment.NewLine}Bye, {botBrain.UserName}! Stay safe out there!", Brushes.LightGreen);

            UserInputTextBox.IsEnabled = false;
            BtnSend.IsEnabled = false;
            BtnPhishingTip.IsEnabled = false;

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(1300);
            timer.Tick += (s, e) => {
                timer.Stop();
                Application.Current.Shutdown();
            };
            timer.Start();
        }

        private void BtnSend_Click(object sender, RoutedEventArgs e) => ProcessMessageCycle();
        private void BtnExit_Click(object sender, RoutedEventArgs e) => ExecuteSafeShutdownSequence();

        private void BtnPhishingTip_Click(object sender, RoutedEventArgs e)
        {
            UserInputTextBox.Text = "Give me a phishing tip.";
            ProcessMessageCycle();
        }

        private void UserInputTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                ProcessMessageCycle();
            }
        }
    
            }
        }
    
