﻿using System;
using System.Media;

namespace greeting_and_meeting
{//start namespace
    public class greet_voice
    {//start of classs

        //auto path
        string path = AppDomain.CurrentDomain.BaseDirectory;
        public greet_voice()
        {//start constructor

            //call the voice method 
            voice();

        }//end constructor

        //method to voice greet the user 
        private void voice()
        {//start of method 

            //get the ful path replace of Bin\Debug\
            string fullpath = path.Replace(@"bin\Debug\", "");

            //play the sound
            string joined_path = fullpath + "greet_voice.wav";

            //create an instance for the soundPlayer class
            SoundPlayer voice_play = new SoundPlayer(joined_path);

            //loud the audio
            voice_play.Load();

            //play till the end 
            voice_play.Play();

            //end of voice method 

        }//end of method



    }//end of class
}//end of namespace