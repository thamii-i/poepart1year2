﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ai_response
{
    public class ResponseEngine
    {
        private List<string> ignore = new List<string>();
        private List<string> answers = new List<string>();

        public ResponseEngine()
        {
            // Things for the bot to ignore (noise words)
            ignore.Add("please");
            ignore.Add("can");
            ignore.Add("you");
            ignore.Add("tell");
            ignore.Add("me");
            ignore.Add("about");

            // Valid topics the bot can answer
            answers.Add("password");
            answers.Add("phishing");
            answers.Add("purpose");
            answers.Add("how are you");
        }

        public string GetResponse(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return "I didn't quite catch that. Could you please type something?";
            }

            // Clean the input
            string cleanInput = input.ToLower().Trim();

            // Split into words and remove ignored words
            var words = cleanInput.Split(' ').Where(w => !ignore.Contains(w)).ToList();
            string filteredInput = string.Join(" ", words);

            // Logic check against the answers list
            if (answers.Any(a => filteredInput.Contains(a) || cleanInput.Contains(a)))
            {
                if (cleanInput.Contains("how are you"))
                    return "All systems are stable and encrypted. How can I help you today?";

                if (cleanInput.Contains("purpose"))
                    return "My purpose is to help you stay safe online by teaching you about cybersecurity.";

                if (cleanInput.Contains("password"))
                    return "SECURITY TIP: Use a unique passphrase of 16+ characters for every account.";

                if (cleanInput.Contains("phishing"))
                    return "SECURITY TIP: Never click links in unexpected emails. Always verify the sender.";
            }

            //Default response for unknown/invalid input
            return "I'm sorry, I don't have information on that. Try asking about passwords or phishing!";
        }
    }
}