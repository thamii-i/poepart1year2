﻿
using System;
using System.Media;
using System.Threading;
using ai_response;

namespace greeting_and_meeting
{
    class Program
    {
        static void Main(string[] args)
        {
            new greet_voice() { };
            DisplayAsciiLogo();

            Console.ForegroundColor = ConsoleColor.Cyan;
            TypeWriterEffect("Welcome to the Cybersecurity Awareness Bot!");
            Console.ResetColor();

            string userName = "";
            while (string.IsNullOrWhiteSpace(userName))
            {
                Console.Write("\nPlease enter your name to begin: ");
                userName = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(userName))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Entry cannot be empty. Please enter a valid name.");
                    Console.ResetColor();
                }
            }

            Console.WriteLine($"\nHello {userName}! Let's talk about staying safe online.");
            Console.WriteLine(new string('=', 60));

            ResponseEngine botBrain = new ResponseEngine();
            bool running = true;

            while (running)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write($"\n[{userName}]: ");
                Console.ResetColor();

                string input = Console.ReadLine();

                if (input.ToLower() == "exit" || input.ToLower() == "quit")
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"\n[LOGOUT] Bye {userName}!");
                    Console.ResetColor();
                    Thread.Sleep(1500);
                    running = false;
                    continue;
                }

                string response = botBrain.GetResponse(input);

                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("\nAiTATAV: ");
                TypeWriterEffect(response);
                Console.ResetColor();
            }
        }

        static void DisplayAsciiLogo()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine(@"
            ###############################################################################
###############################################+.################################################
##########################################+-..--+---+++##########################################
#########################################.-+##########+##########################################
#######################################+.-#############++########################################
######################################+--###############+#+######################################
######################################+.+###############++-######################################
######################################+++###############++-######################################
######################################+++###############+--######################################
######################################-.-###############---######################################
####################################.........................####################################
###################################..---++---......-+--++--+-.###################################
##################################+.+###++#####+++#####++++++.+##################################
###################################+-##--+#-.........-##--+##+###################################
###################################+###-+#+...####+...+#--##++###################################
###################################--##.++-..#######..-+-.##--###################################
###################################-+##.-+-..#######..+#--###+###################################
#######################################..++-..+###+....-..##++###################################
###################################-#####+##-..###...#-+####+-###################################
############################################-..+##..+###+++######################################
###################################.--########.....-###+##-++.-##################################
###################################.--########+#-++########++..##################################
###################################..-..+#----++..+..-+##..+..###################################
###################################+....-+.......-...-.-.....+###################################
###################################################################

            ");
            Console.ResetColor();
        }

        static void TypeWriterEffect(string message)
        {
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(20);
            }
            Console.WriteLine();
        }
    }
}